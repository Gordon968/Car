// CarDlg.cpp : implementation file
//

#include "stdafx.h"
#include "Car.h"
#include "CarDlg.h"
#include <math.h>
#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	enum { IDD = IDD_ABOUTBOX };

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

// Implementation
protected:
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
END_MESSAGE_MAP()


// CCarDlg dialog



CCarDlg::CCarDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CCarDlg::IDD, pParent)
{
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CCarDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_EDIT_DOWN, m_downPay);
	DDX_Control(pDX, IDC_EDIT_MONTH, m_month);
	DDX_Control(pDX, IDC_EDIT_RATE, m_rate);
	DDX_Control(pDX, IDC_EDIT_TIME, m_time);
	DDX_Control(pDX, IDC_EDIT_TOTALPAY, m_totalPay);
	DDX_Control(pDX, IDC_EDIT_TOTAL_PRICE, m_totalPrice);
}

BEGIN_MESSAGE_MAP(CCarDlg, CDialog)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	//}}AFX_MSG_MAP
   ON_BN_CLICKED(IDC_BUTTON_CALCULATE, &CCarDlg::OnBnClickedButtonCalculate)
END_MESSAGE_MAP()


// CCarDlg message handlers

BOOL CCarDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon

	// TODO: Add extra initialization here
	
	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CCarDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CCarDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, reinterpret_cast<WPARAM>(dc.GetSafeHdc()), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this function to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CCarDlg::OnQueryDragIcon()
{
	return static_cast<HCURSOR>(m_hIcon);
}

void CCarDlg::OnBnClickedButtonCalculate()
{
   //Formular is: T_itime = 0 = (Total * (1+r))(1+r)^itime - monthpay * ( (1+r)^itime + (1+r)^(itime-1) + .. + (1+r) )
	//solve monthpay = (Total * (1+r))(1+r)^itime * r / ((1+r)^(itime+1)-1-r)
	//
   CString csTotal, csRate, csTime, csDown;
	m_totalPrice.GetWindowText(csTotal);
	m_downPay.GetWindowText(csDown);
	m_rate.GetWindowText(csRate);
	m_time.GetWindowText(csTime);

	float fTotal = atof(csTotal.GetBuffer());
	float fRate = atof(csRate.GetBuffer())/1200.0;
	int iDownPay = atoi(csDown.GetBuffer());
	int iTime = atoi(csTime.GetBuffer());

	float fMonthPay = 0.0;
	float fTotalPay = 0.0;

	if( iTime == 0 ) 
	{
		fMonthPay = (fTotal - iDownPay );
		fTotalPay = fTotal;
	}
	else 
	{
		fMonthPay = (fRate == 0.0 ) ? (fTotal - iDownPay)/iTime : (fTotal - iDownPay)*pow((double)(1+fRate),(double)(iTime+1))*fRate/(pow((double)(1+fRate), (double)(iTime+1))-1.0 - fRate);
		fTotalPay = fMonthPay * iTime + iDownPay;
	}
		
	

	CString csMonth, csTotalPay;
	csMonth.Format(_T("%f"), fMonthPay);
	csTotalPay.Format(_T("%f"), fTotalPay);

	m_totalPay.SetWindowText(csTotalPay);
	m_month.SetWindowText(csMonth);
}
